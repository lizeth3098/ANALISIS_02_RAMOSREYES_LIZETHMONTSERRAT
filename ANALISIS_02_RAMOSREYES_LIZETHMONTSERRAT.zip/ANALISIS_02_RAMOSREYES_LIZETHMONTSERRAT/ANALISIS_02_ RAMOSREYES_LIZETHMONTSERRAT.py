# -*- coding: utf-8 -*-
"""
Created on Sun Oct 10 17:46:07 2021

@author: Lizeth
"""

import csv
from tabulate import tabulate
###lista de registros en la base de datos
lista_DB=[]


with open("synergy_logistics_database.csv","r") as DB_csv:
    lector=csv.DictReader(DB_csv)
    
    for linea in lector:
        lista_DB.append(linea)
        


#Bienvenida
print("\n Bienvenidx al análisis el proyecto número 2: \n INTRODUCCIÓN AL ANÁLISIS DE DATOS \n ")

#Menú de opciones para analizar               
accion=0
while accion==0:
    accion= input("""Seleccione el análisis que gusta visualizar:\n
               1. Ver el análisis de la opción 1) Rutas de importación y exportación.
               2. Ver el análisis de la opción opción 2) Medio de transporte utilizado.
               3. Ver el análisis de la opción opción 3) Valor total de importaciones y exportaciones.
               4.Salir
               
               """)
    if accion=="1":
        
        #función para ver las rutas más demandadas de importación y exportación
        def rutas_demandadas(origen):
            contador=0
            value=0
            rutas_contadas=[]
            rutas_conteo=[]
            
            for ruta in lista_DB:
                if ruta["direction"] == origen:
                    ruta_actual=[ruta["origin"], ruta ["destination"]]
                    
                    if ruta_actual not in rutas_contadas:
                        for rutaDB in lista_DB:
                            #conteo de veces que se presenta la ruta
                            if ruta_actual == [rutaDB["origin"], rutaDB["destination"]] and rutaDB["direction"]==origen:
                                contador+=1
                                #suma del valor total de cada venta
                                value += int(rutaDB["total_value"])
                        #añadir la ruta analizada para no volver a contarla
                        rutas_contadas.append(ruta_actual)
                        #añadir los resultados de la ruta analizada
                        rutas_conteo.append([ruta["origin"], ruta ["destination"], contador, value])
                        contador=0
                        value=0
                
            #ordenar según el valor total
            rutas_conteo.sort(reverse=True, key = lambda x:x[3])
            #tomar solo las 10 rutas más importantes
            i=len(rutas_conteo)
            while i>10:
                for linea in rutas_conteo:
                    if i>10:
                        rutas_conteo.pop(-1)
                        i-=1
                    else:
                        continue
            retornar= tabulate(rutas_conteo,headers=["Origin", "Destination", "Conteo","Valor"])
            return retornar

        #Imprimir resultados
        ruta_exportacion= rutas_demandadas("Exports")
        ruta_importacion= rutas_demandadas("Imports")
        print ("\n Las 10 rutas de exportación más importantes ordenadas según los valores totales son: \n\n ", ruta_exportacion,"\n ")
        print ("Las 10 rutas de importación más importantes ordenadas según los valores totales son: \n \n",ruta_importacion,"\n ")
        accion=0
    elif accion=="2":
        
        #Opcion 2 Medio de transporte utilizado.
        def rutas_demandadas():
            contador=0
            value=0
            medios=[]
            medios_contados=[]
            medios_conteo=[]
            
            for medio in lista_DB:
                if medio["transport_mode"] not in medios_contados:
                    medio_actual=medio["transport_mode"]
                    for transporte in lista_DB:
                        if medio_actual==transporte["transport_mode"]:
                            contador+=1
                            value += int(transporte["total_value"])
                    medios_contados.append(medio_actual)
                    medios_conteo.append([medio["transport_mode"],contador,value])
                    contador=0
                    value=0
            #ordenar según valor total
            medios_conteo.sort(reverse=True, key= lambda t:t[2])
            retornar= tabulate(medios_conteo,headers=["Transporte", "Conteo","Valor"])
            return retornar
        
        #impresión de resultados
        print("\n Los medios de transporte más demandados ordenados según los valores totales son: \n\n ",rutas_demandadas())
        accion=0
        
        
    elif accion=="3":
        # Opción 3) Valor total de importaciones y exportaciones.   
        def paises(direccion):
            contador=0
            value=0
            paises=[]
            paises_contados=[]
            paises_conteo=[]
            
            for pais in lista_DB:
                if pais["origin"] not in paises_contados:
                    pais_actual=pais["origin"]
                    for origen in lista_DB:
                        if pais_actual==origen["origin"] and origen["direction"]==direccion:
                            contador+=1
                            value += int(origen["total_value"])
                        else:
                            continue
                    paises_contados.append(pais_actual)
                    paises_conteo.append([pais["origin"],contador,value])
                    contador=0
                    value=0
            #ordenar según valor total
            paises_conteo.sort(reverse=True, key= lambda p:p[2])
            suma=0
            for pais in paises_conteo:
                suma+=pais[2]
            porcentaje=suma*.80
            calculo=0
            paises80=[]
            #cálculo de países que cumplen el 80% y el porcentaje de sus ventas individuales
            for pais in paises_conteo:
                calculo+=pais[2]
                porcentajepaises=pais[2]*100/suma
                if calculo<=porcentaje:
                    paises80.append([pais[0], pais[1],pais[2],porcentajepaises])
                else:
                    continue
            retornar2=tabulate(paises80, headers=["país","Conteo","Valor","porcentaje"])
            return retornar2
    
        
        
        
        print("\n Los países que generan el generan el 80% del valor de las exportaciones ordenados según los valores totales son: \n\n ",paises("Exports"))
        print("\n Los países que generan el generan el 80% del valor de las importaciones ordenados según los valores totales son: \n\n ",paises("Imports"))
        accion=0
    elif accion=="4":
        #terminar el ciclo y salir del programa
        break


        
    